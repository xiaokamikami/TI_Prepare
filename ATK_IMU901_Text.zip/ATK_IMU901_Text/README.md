# WeAct Studio
## LCD Test

测试0.96寸ST7735液晶显示屏

Test the 0.96 inch ST7735 LCD Screen

